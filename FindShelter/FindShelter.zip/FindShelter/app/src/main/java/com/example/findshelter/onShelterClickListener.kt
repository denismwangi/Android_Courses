package com.example.findshelter

import java.text.FieldPosition

interface onShelterClickListener {

    fun onItemClick(item:Shelter, position: Int)
}